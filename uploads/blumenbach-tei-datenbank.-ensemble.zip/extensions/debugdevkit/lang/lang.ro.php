<?php

	$about = array(
		'name' => 'Română',
		'author' => array(
			'name' => 'Vlad Ghita',
			'email' => 'vlad.ghita@xandergroup.ro',
			'website' => ''
		),
		'release-date' => '2011-04-01'
	);

	/**
	 * Debug DevKit
	 */
	$dictionary = array(

		'Debug' => 
		'Depanare',

		'Failed to create cache folder. Please check "%s" is writable.' => 
		'Crearea directorului de cache a eşuat. Verificaţi permisiunea de scriere a "%s".',

		'Cache folder is not writable. Please check permissions on "%s".' => 
		'Directorul de cache nu poate fi scris. Verificaţi permisiunile pentru "%s".',

		'Params' => 
		'Parametri',

		'Result' => 
		'Rezultat',

	);
