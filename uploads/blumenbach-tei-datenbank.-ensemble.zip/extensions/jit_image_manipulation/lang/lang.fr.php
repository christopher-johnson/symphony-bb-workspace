<?php

	$about = array(
		'name' => 'French',
		'author' => array(
			'name' => 'Pierre',
			'email' => 'bonjour@pierrebertet.net',
			'website' => 'http://www.pierrebertet.net'
		),
		'release-date' => '2010-02-12',
	);


	/**
	 * JIT Image Manipulation
	 */
	$dictionary = array(

		'JIT Image Manipulation' => 
		'Manipulation d’images à la volée',

		'Leave empty to disable external linking. Single rule per line. Add * at end for wild card matching.' => 
		'Laissez ce champ vide pour désactiver les liens exernes. Une seule règle par ligne. Utilisez le caractère * en fin de ligne pour autoriser plusieurs URLs.',

		'Trusted Sites' => 
		'Sites de confiance',

	);
