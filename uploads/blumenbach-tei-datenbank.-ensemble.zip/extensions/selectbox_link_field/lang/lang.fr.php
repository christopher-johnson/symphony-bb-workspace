<?php

	$about = array(
		'name' => 'Français',
		'author' => array(
			'name' => 'Deux Huit Huit',
			'email' => 'open-source (at) deuxhuithuit.com',
			'website' => 'http://deuxhuithuit.com/'
		),
		'release-date' => '2014-01-27',
	);


	/*
	 * EXTENSION: Field: Select Box Link
	 * Localisation strings
	 */

	$dictionary = array(

		'Select Box Link' => 
		'Menu de sélection lié',

		'None' =>
		'Aucun',

		'Options' => 
		'Options',

		'Limit to the %s most recent entries' => 
		'Limiter aux %s entrées les plus récentes',

		'Allow selection of multiple options' => 
		'Permettre la section de multiple options'

	);
	