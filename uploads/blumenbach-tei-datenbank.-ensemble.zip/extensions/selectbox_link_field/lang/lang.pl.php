<?php

	$about = array(
		'name' => 'Polish',
		'author' => array(
			'name' => 'Idea07',
			'email' => 'studio@idea07.pl',
			'website' => ''
		),
		'release-date' => '2013-06-17'
	);

	/**
	 * Select Box Link Field
	 */
	$dictionary = array(

		// Missing

		'Select Box Link' => 
		'Select Box Link',

		'Values' => 
		'Wartości',

		'Limit to %s entries' => 
		'Ogranicz do %s wpisów',

		'Allow selection of multiple options' => 
		'Pozwól na zaznaczanie wielu opcji',

	);
