<?php

	Class migration_223 extends Migration{

		static function getVersion(){
			return '2.2.3';
		}

		static function getReleaseNotes(){
			return 'http://getsymphony.com/download/releases/version/2.2.3/';
		}

	}
