<?php

	Class migration_224 extends Migration{

		static function getVersion(){
			return '2.2.4';
		}

		static function getReleaseNotes(){
			return 'http://getsymphony.com/download/releases/version/2.2.4/';
		}

	}
