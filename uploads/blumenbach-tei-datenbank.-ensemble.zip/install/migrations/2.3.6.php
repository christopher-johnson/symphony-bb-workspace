<?php

	Class migration_236 extends Migration {

		static function getVersion(){
			return '2.3.6';
		}

		static function getReleaseNotes(){
			return 'http://getsymphony.com/download/releases/version/2.3.6/';
		}

	}
